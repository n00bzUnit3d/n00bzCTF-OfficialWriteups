#include <stdio.h>
int main() {
	char welcome[71] = "Welcome to the challenge series of basic and intermidate pwn! Good luck";
	printf("%s\n",welcome);
	char buf[50];
	fgets(buf,0x100,stdin);
	return 0;
}
void win() {
	system("sh");
}