from dis import dis
f = open('chall.py').read()
dis(f)